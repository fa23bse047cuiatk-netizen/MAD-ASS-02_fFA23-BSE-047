// MapExplorer.jsx
// Dependencies:
//   expo install expo-location
//   npx expo install react-native-maps

import * as Location from "expo-location";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import MapView, {
  Callout,
  Circle,
  Marker,
  Polygon,
  Polyline,
  PROVIDER_GOOGLE,
} from "react-native-maps";

// ─── Nearby places (static demo data) ──────────────────────────────────────
const NEARBY_PLACES = [
  {
    id: 1,
    title: "Badshahi Mosque",
    desc: "Historic Mughal mosque",
    lat: 31.5882,
    lng: 74.3098,
    color: "#FF6B6B",
  },
  {
    id: 2,
    title: "Lahore Fort",
    desc: "UNESCO World Heritage Site",
    lat: 31.5882,
    lng: 74.3154,
    color: "#4ECDC4",
  },
  {
    id: 3,
    title: "Shalimar Garden",
    desc: "Mughal-era garden",
    lat: 31.5921,
    lng: 74.3824,
    color: "#45B7D1",
  },
  {
    id: 4,
    title: "Data Darbar",
    desc: "Sufi shrine & landmark",
    lat: 31.5697,
    lng: 74.3109,
    color: "#FFA07A",
  },
  {
    id: 5,
    title: "Anarkali Bazaar",
    desc: "Oldest bazaar in South Asia",
    lat: 31.568,
    lng: 74.3157,
    color: "#98D8C8",
  },
];

// ─── Map style options ───────────────────────────────────────────────────────
const MAP_TYPES = ["standard", "satellite", "hybrid", "terrain"];

// ─── Polygon coords for demo ─────────────────────────────────────────────────
const POLYGON_COORDS = [
  { latitude: 31.575, longitude: 74.305 },
  { latitude: 31.58, longitude: 74.325 },
  { latitude: 31.57, longitude: 74.33 },
  { latitude: 31.563, longitude: 74.315 },
];

// ─── Polyline route (demo) ───────────────────────────────────────────────────
const ROUTE_COORDS = [
  { latitude: 31.52, longitude: 74.3587 },
  { latitude: 31.535, longitude: 74.34 },
  { latitude: 31.55, longitude: 74.325 },
  { latitude: 31.5697, longitude: 74.3109 },
  { latitude: 31.5882, longitude: 74.3098 },
];

export default function MapExplorer() {
  const mapRef = useRef(null);

  // ── State ──────────────────────────────────────────────────────────────────
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mapType, setMapType] = useState("standard");
  const [mapTypeIndex, setMapTypeIndex] = useState(0);
  const [showCircle, setShowCircle] = useState(true);
  const [showPolygon, setShowPolygon] = useState(false);
  const [showPolyline, setShowPolyline] = useState(false);
  const [showPlaces, setShowPlaces] = useState(true);
  const [tracking, setTracking] = useState(false);
  const [watchSub, setWatchSub] = useState(null);
  const [speed, setSpeed] = useState(null);
  const [altitude, setAltitude] = useState(null);
  const [heading, setHeading] = useState(null);
  const [accuracy, setAccuracy] = useState(null);
  const [selectedPlace, setSelectedPlace] = useState(null);

  // ── Get initial location ───────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Location permission denied.");
        setLoading(false);
        return;
      }
      try {
        const loc = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.High,
        });
        setLocation(loc.coords);
        setSpeed(loc.coords.speed);
        setAltitude(loc.coords.altitude);
        setHeading(loc.coords.heading);
        setAccuracy(loc.coords.accuracy);
      } catch (e) {
        setErrorMsg("Could not fetch location.");
      }
      setLoading(false);
    })();

    return () => {
      if (watchSub) watchSub.remove();
    };
  }, []);

  // ── Live tracking toggle ───────────────────────────────────────────────────
  const toggleTracking = async () => {
    if (tracking) {
      watchSub && watchSub.remove();
      setWatchSub(null);
      setTracking(false);
    } else {
      const sub = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 2000,
          distanceInterval: 5,
        },
        (loc) => {
          setLocation(loc.coords);
          setSpeed(loc.coords.speed);
          setAltitude(loc.coords.altitude);
          setHeading(loc.coords.heading);
          setAccuracy(loc.coords.accuracy);
          animateToLocation(loc.coords);
        },
      );
      setWatchSub(sub);
      setTracking(true);
    }
  };

  // ── Animate map camera ─────────────────────────────────────────────────────
  const animateToLocation = (coords) => {
    mapRef.current?.animateToRegion(
      {
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      },
      800,
    );
  };

  // ── Cycle map type ─────────────────────────────────────────────────────────
  const cycleMapType = () => {
    const next = (mapTypeIndex + 1) % MAP_TYPES.length;
    setMapTypeIndex(next);
    setMapType(MAP_TYPES[next]);
  };

  // ── Show coordinates alert ─────────────────────────────────────────────────
  const showCoords = () => {
    if (!location) return;
    Alert.alert(
      "📍 Your Coordinates",
      `Latitude:  ${location.latitude.toFixed(6)}\nLongitude: ${location.longitude.toFixed(6)}\nAccuracy:  ${accuracy ? accuracy.toFixed(1) + " m" : "N/A"}`,
    );
  };

  // ── Loading / Error screens ────────────────────────────────────────────────
  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#00C9A7" />
        <Text style={styles.loadingText}>Fetching location…</Text>
      </View>
    );
  }

  if (errorMsg) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>⚠️ {errorMsg}</Text>
      </View>
    );
  }

  const region = {
    latitude: location?.latitude ?? 31.5204,
    longitude: location?.longitude ?? 74.3587,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  };

  // ── Main render ────────────────────────────────────────────────────────────
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0D1117" />

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🗺 Map Explorer</Text>
        <Text style={styles.headerSub}>react-native-maps + expo-location</Text>
      </View>

      {/* ── Map ────────────────────────────────────────────────────────────── */}
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        mapType={mapType}
        initialRegion={region}
        showsUserLocation={true}
        showsMyLocationButton={false}
        showsCompass={true}
        showsScale={true}
        showsTraffic={false}
        showsBuildings={true}
        showsIndoors={true}
        rotateEnabled={true}
        pitchEnabled={true}
        zoomEnabled={true}
        scrollEnabled={true}
        onPress={() => setSelectedPlace(null)}
      >
        {/* ── User Location Marker ──────────────────────────────────────── */}
        {location && (
          <Marker
            coordinate={{
              latitude: location.latitude,
              longitude: location.longitude,
            }}
            title="You are here"
            description={`Lat: ${location.latitude.toFixed(4)}, Lng: ${location.longitude.toFixed(4)}`}
            pinColor="#00C9A7"
            onPress={showCoords}
          >
            <View style={styles.userMarker}>
              <View style={styles.userMarkerInner} />
            </View>
            <Callout tooltip>
              <View style={styles.callout}>
                <Text style={styles.calloutTitle}>📍 Your Location</Text>
                <Text style={styles.calloutText}>
                  {location.latitude.toFixed(5)},{" "}
                  {location.longitude.toFixed(5)}
                </Text>
                {speed != null && (
                  <Text style={styles.calloutText}>
                    Speed: {(speed * 3.6).toFixed(1)} km/h
                  </Text>
                )}
              </View>
            </Callout>
          </Marker>
        )}

        {/* ── Accuracy Circle ───────────────────────────────────────────── */}
        {showCircle && location && (
          <Circle
            center={{
              latitude: location.latitude,
              longitude: location.longitude,
            }}
            radius={accuracy ?? 100}
            strokeColor="rgba(0,201,167,0.8)"
            fillColor="rgba(0,201,167,0.15)"
            strokeWidth={2}
          />
        )}

        {/* ── Nearby Places Markers ─────────────────────────────────────── */}
        {showPlaces &&
          NEARBY_PLACES.map((place) => (
            <Marker
              key={place.id}
              coordinate={{ latitude: place.lat, longitude: place.lng }}
              title={place.title}
              description={place.desc}
              pinColor={place.color}
              onPress={() => setSelectedPlace(place)}
            >
              <View style={[styles.placeMarker, { borderColor: place.color }]}>
                <Text style={styles.placeMarkerText}>{place.id}</Text>
              </View>
              <Callout tooltip>
                <View style={[styles.callout, { borderColor: place.color }]}>
                  <Text style={[styles.calloutTitle, { color: place.color }]}>
                    {place.title}
                  </Text>
                  <Text style={styles.calloutText}>{place.desc}</Text>
                </View>
              </Callout>
            </Marker>
          ))}

        {/* ── Polygon ───────────────────────────────────────────────────── */}
        {showPolygon && (
          <Polygon
            coordinates={POLYGON_COORDS}
            strokeColor="#FF6B6B"
            fillColor="rgba(255,107,107,0.2)"
            strokeWidth={2}
          />
        )}

        {/* ── Polyline (Route) ──────────────────────────────────────────── */}
        {showPolyline && (
          <Polyline
            coordinates={ROUTE_COORDS}
            strokeColor="#FFD700"
            strokeWidth={4}
            lineDashPattern={[10, 5]}
          />
        )}
      </MapView>

      {/* ── Info Bar ───────────────────────────────────────────────────────── */}
      <View style={styles.infoBar}>
        <InfoChip icon="📡" label="Map" value={mapType} />
        <InfoChip
          icon="⚡"
          label="Speed"
          value={speed != null ? `${(speed * 3.6).toFixed(1)} km/h` : "—"}
        />
        <InfoChip
          icon="⛰"
          label="Alt"
          value={altitude != null ? `${altitude.toFixed(0)} m` : "—"}
        />
        <InfoChip
          icon="🎯"
          label="Acc"
          value={accuracy != null ? `${accuracy.toFixed(0)} m` : "—"}
        />
      </View>

      {/* ── Controls ScrollView ────────────────────────────────────────────── */}
      <ScrollView
        style={styles.controls}
        contentContainerStyle={styles.controlsContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Action Buttons */}
        <View style={styles.buttonRow}>
          <ControlBtn
            label={tracking ? "⏹ Stop Track" : "▶ Live Track"}
            onPress={toggleTracking}
            active={tracking}
            color="#00C9A7"
          />
          <ControlBtn
            label="🔄 Map Type"
            onPress={cycleMapType}
            color="#7B8CDE"
          />
          <ControlBtn
            label="📍 Center Me"
            onPress={() => location && animateToLocation(location)}
            color="#FFA07A"
          />
        </View>

        {/* Toggles */}
        <View style={styles.toggleGroup}>
          <ToggleRow
            label="📏 Accuracy Circle"
            value={showCircle}
            onToggle={setShowCircle}
          />
          <ToggleRow
            label="📍 Nearby Places"
            value={showPlaces}
            onToggle={setShowPlaces}
          />
          <ToggleRow
            label="⬡  Polygon Zone"
            value={showPolygon}
            onToggle={setShowPolygon}
          />
          <ToggleRow
            label="〰  Route Polyline"
            value={showPolyline}
            onToggle={setShowPolyline}
          />
        </View>

        {/* Selected Place Card */}
        {selectedPlace && (
          <View
            style={[styles.placeCard, { borderColor: selectedPlace.color }]}
          >
            <Text
              style={[styles.placeCardTitle, { color: selectedPlace.color }]}
            >
              {selectedPlace.title}
            </Text>
            <Text style={styles.placeCardDesc}>{selectedPlace.desc}</Text>
            <Text style={styles.placeCardCoords}>
              {selectedPlace.lat.toFixed(4)}, {selectedPlace.lng.toFixed(4)}
            </Text>
          </View>
        )}

        {/* Components Reference */}
        <View style={styles.refCard}>
          <Text style={styles.refTitle}>react-native-maps Components Used</Text>
          {[
            ["MapView", "Base map container"],
            ["Marker", "Custom & default pins"],
            ["Callout", "Tooltip on marker tap"],
            ["Circle", "Accuracy radius ring"],
            ["Polygon", "Filled zone boundary"],
            ["Polyline", "Dashed route path"],
          ].map(([comp, desc]) => (
            <View key={comp} style={styles.refRow}>
              <Text style={styles.refComp}>{comp}</Text>
              <Text style={styles.refDesc}>{desc}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

// ─── Small reusable components ───────────────────────────────────────────────

const InfoChip = ({ icon, label, value }) => (
  <View style={styles.chip}>
    <Text style={styles.chipIcon}>{icon}</Text>
    <Text style={styles.chipLabel}>{label}</Text>
    <Text style={styles.chipValue}>{value}</Text>
  </View>
);

const ControlBtn = ({ label, onPress, active, color }) => (
  <TouchableOpacity
    style={[
      styles.btn,
      {
        borderColor: color,
        backgroundColor: active ? color + "30" : "transparent",
      },
    ]}
    onPress={onPress}
    activeOpacity={0.7}
  >
    <Text style={[styles.btnText, { color }]}>{label}</Text>
  </TouchableOpacity>
);

const ToggleRow = ({ label, value, onToggle }) => (
  <View style={styles.toggleRow}>
    <Text style={styles.toggleLabel}>{label}</Text>
    <Switch
      value={value}
      onValueChange={onToggle}
      trackColor={{ false: "#2D2D3F", true: "#00C9A7" }}
      thumbColor={value ? "#fff" : "#666"}
    />
  </View>
);

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0D1117" },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0D1117",
  },
  loadingText: {
    color: "#00C9A7",
    marginTop: 12,
    fontSize: 14,
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  errorText: {
    color: "#FF6B6B",
    fontSize: 16,
    textAlign: "center",
    padding: 20,
  },

  // Header
  header: {
    backgroundColor: "#161B22",
    paddingTop: StatusBar.currentHeight ? StatusBar.currentHeight + 8 : 48,
    paddingBottom: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#30363D",
  },
  headerTitle: {
    color: "#E6EDF3",
    fontSize: 20,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  headerSub: { color: "#7D8590", fontSize: 11, marginTop: 2 },

  // Map
  map: { height: 280 },

  // Info bar
  infoBar: {
    flexDirection: "row",
    backgroundColor: "#161B22",
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    borderBottomColor: "#30363D",
  },
  chip: { flex: 1, alignItems: "center" },
  chipIcon: { fontSize: 14 },
  chipLabel: { color: "#7D8590", fontSize: 9, marginTop: 1 },
  chipValue: { color: "#E6EDF3", fontSize: 11, fontWeight: "600" },

  // Controls
  controls: { flex: 1, backgroundColor: "#0D1117" },
  controlsContent: { padding: 12, paddingBottom: 30 },

  buttonRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  btn: {
    flex: 1,
    paddingVertical: 9,
    paddingHorizontal: 6,
    borderRadius: 8,
    borderWidth: 1.5,
    alignItems: "center",
  },
  btnText: { fontSize: 11, fontWeight: "600" },

  toggleGroup: {
    backgroundColor: "#161B22",
    borderRadius: 12,
    marginBottom: 12,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#30363D",
  },
  toggleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#30363D",
  },
  toggleLabel: { color: "#C9D1D9", fontSize: 13 },

  // Markers
  userMarker: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "rgba(0,201,167,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#00C9A7",
  },
  userMarkerInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#00C9A7",
  },
  placeMarker: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: "#161B22",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
  },
  placeMarkerText: { color: "#E6EDF3", fontSize: 11, fontWeight: "700" },

  // Callout
  callout: {
    backgroundColor: "#161B22",
    borderRadius: 8,
    padding: 10,
    minWidth: 140,
    borderWidth: 1.5,
    borderColor: "#30363D",
  },
  calloutTitle: {
    color: "#00C9A7",
    fontWeight: "700",
    fontSize: 13,
    marginBottom: 3,
  },
  calloutText: { color: "#C9D1D9", fontSize: 11 },

  // Place card
  placeCard: {
    backgroundColor: "#161B22",
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1.5,
  },
  placeCardTitle: { fontSize: 15, fontWeight: "700", marginBottom: 3 },
  placeCardDesc: { color: "#C9D1D9", fontSize: 12, marginBottom: 4 },
  placeCardCoords: { color: "#7D8590", fontSize: 11 },

  // Reference card
  refCard: {
    backgroundColor: "#161B22",
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: "#30363D",
  },
  refTitle: {
    color: "#7D8590",
    fontSize: 11,
    fontWeight: "600",
    marginBottom: 10,
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  refRow: { flexDirection: "row", alignItems: "center", marginBottom: 7 },
  refComp: {
    color: "#79C0FF",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
    fontSize: 12,
    width: 100,
  },
  refDesc: { color: "#8B949E", fontSize: 12 },
});
